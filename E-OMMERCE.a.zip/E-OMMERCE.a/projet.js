let cartIcon =document.getElementById("#bag-icons");
let cart = document.querySelector(".cart");
let closeCart = document.getElementById("#close-cart");

let shopContent=document.getElementsByClassName(".shop-content");
function active1(){
    shopContent.classList.add("active");
}
function active(){
    cart.classList.add("active");
}
function remov(){
    cart.classList.remove("active");
}
if(document.readyState == "loading"){
    document.addEventListener("DOMContentLoaded",ready);

}
else{
    ready();
}
function ready(){
    var i;
    var button
    var removecartbuttons = document.getElementsByClassName("cart-remove");
  
    for(i=0 ;i<removecartbuttons.length;i++){
        button=removecartbuttons[i];
        button.addEventListener("click",removeCartItems);
    }
   var quantityInput = document.getElementsByClassName('cart-quantity');
   for(var i=0 ;i<quantityInput.length;i++){
    var input = quantityInput[i];
    input.addEventListener("change",quantityChanges);
}
    var addcart = document.getElementsByClassName('add-cart');
    for(i=0 ;i<addcart.length;i++){
        var button = addcart[i];
        button.addEventListener("click",addcartClicked);
}
document.getElementsByClassName("btn-buy")[0].addEventListener("click",byButtonClicked);
}
function byButtonClicked(){
    window.location.href = 'payment.html';
    var cartcontent = document.getElementsByClassName("cart-content")[0];
    while(cartcontent.hasChildNodes()){
        cartcontent.removeChild(cartcontent.firstChild);
    }
    total();
}
function removeCartItems(event){
    var buttonClicked = event.target;
    buttonClicked.parentElement.remove()
    total();
}
function quantityChanges(event){
    var input =event.target;
    if(isNaN(input.value) || input.value <=0){
        input.value=1;
    }
    total();

}
function addcartClicked(event){
    var button = event.target;
    var shopproducts= button.parentElement;
    var title = shopproducts.getElementsByClassName("product-title")[0].innerText;
    var price = shopproducts.getElementsByClassName("price")[0].innerText;
    var proimg = shopproducts.getElementsByClassName("product-img")[0].src;
    addProductTocart(title,price,proimg);
    total();
}

function addProductTocart(title,price,proimg){
    var cartshopbox = document.createElement("div");
    cartshopbox.classList.add("cart-box");
    var cartItems = document.getElementsByClassName("cart-content")[0];
    var cartItemsName= cartItems.getElementsByClassName("cart-product-title");
    for(var i=0;i< cartItemsName.length;i++){
        if(cartItemsName[i].innerText == title){
           alert("you have already add this items to cart");  
        return;
        
        }
        
    }



    var cartboxcontent=`<img src="${proimg}"  alt="" class="cart-img">
    <div class="detail-box">
        <div class="cart-product-title">${title}</div>
        <div class="cart-price">${price}</div>
        <input type="number" value="1" class="cart-quantity">
    </div>
    <i class='bx bxs-trash cart-remove'></i><br>`;
cartshopbox.innerHTML = cartboxcontent;
cartItems.append(cartshopbox);
cartshopbox.getElementsByClassName("cart-remove")[0].addEventListener('click',removeCartItems);
cartshopbox.getElementsByClassName("cart-quantity")[0].addEventListener('change',quantityChanges);}
function total(){
    var cartcontent =document.getElementsByClassName('cart-content')[0];
    var cartBoxes = cartcontent.getElementsByClassName('cart-box');
    let i;
    var Total=0;
    for(i=0 ;i<cartBoxes.length;i++){
        var cartBox =cartBoxes[i];
        var priceElement =cartBox.getElementsByClassName("cart-price")[0];
        var quantityElement = cartBox.getElementsByClassName("cart-quantity")[0];
        var quantity =quantityElement.value;
        var price=parseFloat(priceElement.innerText.replace('dhs',""))
        Total=Total + (price *quantity);}
    
        document.getElementsByClassName("total-price")[0].innerText =  Total+"DH";
    
}
